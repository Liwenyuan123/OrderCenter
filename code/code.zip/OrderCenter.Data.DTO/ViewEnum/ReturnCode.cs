﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderCenter.Data.DTO.ViewEnum
{
    public enum ReturnCode
    {
        NO_METHOD = 1001,
        OPERATION_FAILED = 1002,
        OK =0
    }
}
