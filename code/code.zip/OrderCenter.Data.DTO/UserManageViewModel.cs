﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderCenter.Data.DTO
{
   public class UserManageViewModel
    {
        public string Uid { get; set; }
        public string LoginID { get; set; }
        public string UserName { get; set; }
        public string Phone { get; set; }
        public string State { get; set; }
    }
}
